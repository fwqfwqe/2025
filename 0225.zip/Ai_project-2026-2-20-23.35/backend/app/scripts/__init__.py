# Intentionally empty: enables `python -m app.scripts.<name>`.

