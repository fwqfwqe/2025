from .student_experiments import StudentExperimentRepository


class SubmissionRepository(StudentExperimentRepository):
    """Backward-compatible alias repository for student experiment submissions."""
